package net.sf.marineapi.nmea.parser;

import java.lang.reflect.Method;
import org.junit.Before;
import org.junit.Test;
import net.sf.marineapi.nmea.parser.GSAParser;
import net.sf.marineapi.nmea.parser.SentenceParser;
import net.sf.marineapi.nmea.sentence.TalkerId;
import org.mockito.*;
import org.junit.After;
import org.junit.Assert;
import static org.mockito.Mockito.*;
import static org.junit.Assert.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.util.ArrayList;
import java.util.List;
import net.sf.marineapi.nmea.sentence.GSASentence;
import net.sf.marineapi.nmea.sentence.SentenceId;
import net.sf.marineapi.nmea.util.FaaMode;
import net.sf.marineapi.nmea.util.GpsFixStatus;

public class GSAParser_getPositionDOP_3_0_Test {

    private GSAParser gsaParser;

    @Before
    public void setUp() {
        // Using reflection to access the private constructor of SentenceParser
        try {
            Class<?> sentenceParserClass = Class.forName("net.sf.marineapi.nmea.parser.SentenceParser");
            Object sentenceParser = sentenceParserClass.getDeclaredConstructor(String.class).newInstance("$GPGSA,A,3,04,05,,09,12,,,,,1.8,1.0,1.5*33");
            gsaParser = new GSAParser((TalkerId) null);
        } catch (Exception e) {
            fail("Failed to set up the test due to: " + e.getMessage());
        }
    }

    @Test
    public void testGetPositionDOP() {
        try {
            // Using reflection to invoke the protected getDoubleValue method
            Method getDoubleValueMethod = SentenceParser.class.getDeclaredMethod("getDoubleValue", int.class);
            getDoubleValueMethod.setAccessible(true);
            // Setting expected value for POSITION_DOP
            double expectedPDOP = (double) getDoubleValueMethod.invoke(gsaParser, 14);
            // Testing the getPositionDOP method
            double actualPDOP = gsaParser.getPositionDOP();
            assertEquals(expectedPDOP, actualPDOP, 0.001);
        } catch (Exception e) {
            fail("Exception occurred while testing getPositionDOP: " + e.getMessage());
        }
    }
}
