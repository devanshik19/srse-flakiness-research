package io.elasticjob.lite.internal.schedule;

import io.elasticjob.lite.api.listener.ElasticJobListener;
import io.elasticjob.lite.internal.config.ConfigurationService;
import io.elasticjob.lite.internal.election.LeaderService;
import io.elasticjob.lite.internal.instance.InstanceService;
import io.elasticjob.lite.internal.listener.ListenerManager;
import io.elasticjob.lite.internal.monitor.MonitorService;
import io.elasticjob.lite.internal.reconcile.ReconcileService;
import io.elasticjob.lite.internal.server.ServerService;
import io.elasticjob.lite.internal.sharding.ExecutionService;
import io.elasticjob.lite.internal.sharding.ShardingService;
import io.elasticjob.lite.reg.base.CoordinatorRegistryCenter;
import org.junit.Before;
import org.junit.Test;
import java.lang.reflect.Field;
import java.util.Collections;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import io.elasticjob.lite.config.LiteJobConfiguration;
import java.util.List;
import org.junit.After;
import org.junit.Assert;
import org.mockito.*;
import static org.mockito.Mockito.*;
import static org.junit.Assert.*;

@RunWith(MockitoJUnitRunner.class)
public class SchedulerFacade_registerStartUpInfo_2_0_Test {

    @Mock
    private CoordinatorRegistryCenter regCenter;

    @Mock
    private LeaderService leaderService;

    @Mock
    private ServerService serverService;

    @Mock
    private InstanceService instanceService;

    @Mock
    private ShardingService shardingService;

    @Mock
    private ExecutionService executionService;

    @Mock
    private MonitorService monitorService;

    @Mock
    private ReconcileService reconcileService;

    private SchedulerFacade schedulerFacade;

    private ListenerManager listenerManager;

    @Before
    public void setUp() throws Exception {
        MockitoAnnotations.initMocks(this);
        schedulerFacade = new SchedulerFacade(regCenter, "testJob", Collections.<ElasticJobListener>emptyList());
        listenerManager = spy((ListenerManager) getPrivateField(schedulerFacade, "listenerManager"));
        setPrivateField(schedulerFacade, "listenerManager", listenerManager);
        setPrivateField(schedulerFacade, "leaderService", leaderService);
        setPrivateField(schedulerFacade, "serverService", serverService);
        setPrivateField(schedulerFacade, "instanceService", instanceService);
        setPrivateField(schedulerFacade, "shardingService", shardingService);
        setPrivateField(schedulerFacade, "executionService", executionService);
        setPrivateField(schedulerFacade, "monitorService", monitorService);
        setPrivateField(schedulerFacade, "reconcileService", reconcileService);
    }

    private void setPrivateField(Object target, String fieldName, Object value) throws Exception {
        Field field = target.getClass().getDeclaredField(fieldName);
        field.setAccessible(true);
        field.set(target, value);
    }

    private Object getPrivateField(Object target, String fieldName) throws Exception {
        Field field = target.getClass().getDeclaredField(fieldName);
        field.setAccessible(true);
        return field.get(target);
    }

    @Test
    public void testRegisterStartUpInfoWhenReconcileServiceNotRunning() {
        when(reconcileService.isRunning()).thenReturn(false);
        schedulerFacade.registerStartUpInfo(true);
        verify(listenerManager).startAllListeners();
        verify(leaderService).electLeader();
        verify(serverService).persistOnline(true);
        verify(instanceService).persistOnline();
        verify(shardingService).setReshardingFlag();
        verify(monitorService).listen();
        verify(reconcileService).startAsync();
    }

    @Test
    public void testRegisterStartUpInfoWhenReconcileServiceRunning() {
        when(reconcileService.isRunning()).thenReturn(true);
        schedulerFacade.registerStartUpInfo(true);
        verify(listenerManager).startAllListeners();
        verify(leaderService).electLeader();
        verify(serverService).persistOnline(true);
        verify(instanceService).persistOnline();
        verify(shardingService).setReshardingFlag();
        verify(monitorService).listen();
        verify(reconcileService, never()).startAsync();
    }
}
