package net.sf.marineapi.nmea.parser;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.JUnit4;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import net.sf.marineapi.nmea.parser.XDRParser;
import net.sf.marineapi.nmea.util.Measurement;
import net.sf.marineapi.nmea.sentence.TalkerId;
import org.mockito.*;
import org.junit.After;
import org.junit.Assert;
import static org.mockito.Mockito.*;
import static org.junit.Assert.*;
import org.mockito.junit.MockitoJUnitRunner;
import net.sf.marineapi.nmea.sentence.SentenceId;
import net.sf.marineapi.nmea.sentence.XDRSentence;

@RunWith(JUnit4.class)
public class XDRParser_addMeasurement_0_0_Test {

    private XDRParser parser;

    @Before
    public void setUp() {
        // Initialize XDRParser with a TalkerId for testing
        parser = new XDRParser(TalkerId.GP);
    }

    @Test
    public void testAddMeasurement() throws Exception {
        // Create some Measurement instances
        Measurement m1 = new Measurement("type1", 12.34, "units1", "name1");
        Measurement m2 = new Measurement("type2", 56.78, "units2", "name2");
        // Get initial measurements
        List<Measurement> initialMeasurements = parser.getMeasurements();
        // Add measurements using reflection to access private method
        Method addMeasurementMethod = XDRParser.class.getDeclaredMethod("addMeasurement", Measurement[].class);
        addMeasurementMethod.setAccessible(true);
        addMeasurementMethod.invoke(parser, new Object[] { new Measurement[] { m1, m2 } });
        // Get updated measurements
        List<Measurement> updatedMeasurements = parser.getMeasurements();
        // Verify that the measurements were added
        assertEquals(initialMeasurements.size() + 2, updatedMeasurements.size());
        assertTrue(updatedMeasurements.contains(m1));
        assertTrue(updatedMeasurements.contains(m2));
    }
}
