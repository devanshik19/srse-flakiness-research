package com.intuit.karate.core;

import com.intuit.karate.StringUtils;
import com.intuit.karate.core.ScenarioEngine;
import java.lang.reflect.Method;
import org.mockito.*;
import org.junit.jupiter.api.*;
import static org.mockito.Mockito.*;
import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.junit.jupiter.MockitoExtension;
import com.intuit.karate.FileUtils;
import com.intuit.karate.Json;
import com.intuit.karate.JsonUtils;
import com.intuit.karate.KarateException;
import com.intuit.karate.Logger;
import com.intuit.karate.Match;
import com.intuit.karate.RuntimeHook;
import com.intuit.karate.XmlUtils;
import com.intuit.karate.driver.Driver;
import com.intuit.karate.driver.DriverOptions;
import com.intuit.karate.driver.Key;
import com.intuit.karate.graal.JsEngine;
import com.intuit.karate.graal.JsExecutable;
import com.intuit.karate.graal.JsFunction;
import com.intuit.karate.graal.JsLambda;
import com.intuit.karate.graal.JsValue;
import com.intuit.karate.http.*;
import com.intuit.karate.resource.Resource;
import com.intuit.karate.resource.ResourceResolver;
import com.intuit.karate.shell.Command;
import com.intuit.karate.template.KarateTemplateEngine;
import com.intuit.karate.template.TemplateUtils;
import com.jayway.jsonpath.PathNotFoundException;
import org.graalvm.polyglot.Value;
import org.w3c.dom.Attr;
import org.w3c.dom.Document;
import org.w3c.dom.NamedNodeMap;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import java.io.File;
import java.io.InputStream;
import java.security.KeyStore;
import java.util.*;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.TimeUnit;
import java.util.function.BiConsumer;
import java.util.function.Function;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import org.slf4j.LoggerFactory;

public class ScenarioEngine_parseVariableAndPath_110_0_Test {

    @Test
    public void testParseVariableAndPath() throws Exception {
        // Access the private method using reflection
        Method method = ScenarioEngine.class.getDeclaredMethod("parseVariableAndPath", String.class);
        method.setAccessible(true);
        // Test cases
        StringUtils.Pair result1 = (StringUtils.Pair) method.invoke(null, "variableName");
        assertEquals("variableName", result1.left);
        assertEquals("$", result1.right);
        StringUtils.Pair result2 = (StringUtils.Pair) method.invoke(null, "variableName.path");
        assertEquals("variableName", result2.left);
        assertEquals("$.path", result2.right);
        StringUtils.Pair result3 = (StringUtils.Pair) method.invoke(null, "variableName[0]");
        assertEquals("variableName", result3.left);
        assertEquals("$[0]", result3.right);
        StringUtils.Pair result4 = (StringUtils.Pair) method.invoke(null, "variableName/child");
        assertEquals("variableName", result4.left);
        assertEquals("/child", result4.right);
        StringUtils.Pair result5 = (StringUtils.Pair) method.invoke(null, "variableName.function()");
        assertEquals("variableName", result5.left);
        assertEquals("function()", result5.right);
    }
}
