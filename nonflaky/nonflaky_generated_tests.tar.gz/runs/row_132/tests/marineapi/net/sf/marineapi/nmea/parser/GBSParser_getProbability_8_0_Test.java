package net.sf.marineapi.nmea.parser;

import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.List;
import org.junit.Before;
import org.junit.Test;
import net.sf.marineapi.nmea.parser.GBSParser;
import net.sf.marineapi.nmea.sentence.TalkerId;
import org.junit.After;
import org.junit.Assert;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import net.sf.marineapi.nmea.sentence.GBSSentence;
import net.sf.marineapi.nmea.sentence.SentenceId;
import net.sf.marineapi.nmea.util.Time;
import org.mockito.*;
import static org.mockito.Mockito.*;
import static org.junit.Assert.*;

public class GBSParser_getProbability_8_0_Test {

    private GBSParser gbsParser;

    private static final double DELTA = 1e-9;

    @Before
    public void setUp() throws Exception {
        // Initialize GBSParser with a dummy TalkerId
        gbsParser = new GBSParser(TalkerId.GP);
    }

    @Test
    public void testGetProbability() {
        try {
            // Use reflection to access the private fields and methods
            Field fieldsField = gbsParser.getClass().getSuperclass().getDeclaredField("fields");
            fieldsField.setAccessible(true);
            @SuppressWarnings("unchecked")
            List<String> fields = (List<String>) fieldsField.get(gbsParser);
            // Adding a probability value at index 5
            fields.add("0.95");
            Method getDoubleValueMethod = gbsParser.getClass().getSuperclass().getDeclaredMethod("getDoubleValue", int.class);
            getDoubleValueMethod.setAccessible(true);
            // Set the value for PROBABILITY index
            double probability = (double) getDoubleValueMethod.invoke(gbsParser, 5);
            // Assert the expected probability value
            assertEquals(0.95, probability, DELTA);
        } catch (Exception e) {
            fail("Exception during reflection: " + e.getMessage());
        }
    }
}
