package io.elasticjob.lite.internal.election;

import io.elasticjob.lite.internal.election.LeaderService;
import io.elasticjob.lite.internal.server.ServerService;
import io.elasticjob.lite.internal.storage.JobNodeStorage;
import io.elasticjob.lite.reg.base.CoordinatorRegistryCenter;
import io.elasticjob.lite.util.concurrent.BlockUtils;
import io.elasticjob.lite.internal.schedule.JobRegistry;
import io.elasticjob.lite.api.strategy.JobInstance;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import org.junit.After;
import org.junit.Assert;
import io.elasticjob.lite.internal.storage.LeaderExecutionCallback;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.mockito.*;
import static org.mockito.Mockito.*;
import static org.junit.Assert.*;

@RunWith(MockitoJUnitRunner.class)
public class LeaderService_isLeaderUntilBlock_1_2_Test {

    @Mock
    private CoordinatorRegistryCenter regCenter;

    @Mock
    private ServerService serverService;

    @Mock
    private JobNodeStorage jobNodeStorage;

    private LeaderService leaderService;

    private final String jobName = "testJob";

    @Before
    public void setUp() {
        MockitoAnnotations.initMocks(this);
        leaderService = new LeaderService(regCenter, jobName);
    }

    @Test
    public void testIsLeaderUntilBlock() throws Exception {
        JobRegistry jobRegistry = JobRegistry.getInstance();
        JobInstance jobInstance = mock(JobInstance.class);
        when(jobRegistry.getJobInstance(jobName)).thenReturn(jobInstance);
        when(jobInstance.getIp()).thenReturn("127.0.0.1");
        when(serverService.hasAvailableServers()).thenReturn(true, false);
        when(serverService.isAvailableServer(anyString())).thenReturn(true);
        when(jobRegistry.isShutdown(jobName)).thenReturn(false);
        when(jobNodeStorage.isJobNodeExisted(anyString())).thenReturn(false, true);
        when(jobNodeStorage.getJobNodeData(anyString())).thenReturn("127.0.0.1@-@12345");
        Method electLeaderMethod = LeaderService.class.getDeclaredMethod("electLeader");
        electLeaderMethod.setAccessible(true);
        doNothing().when(leaderService).electLeader();
        boolean isLeader = leaderService.isLeaderUntilBlock();
        assertTrue(isLeader);
        verify(serverService, times(2)).hasAvailableServers();
        verify(leaderService, times(1)).electLeader();
    }

    @Test
    public void testIsNotLeaderUntilBlock() throws Exception {
        JobRegistry jobRegistry = JobRegistry.getInstance();
        JobInstance jobInstance = mock(JobInstance.class);
        when(jobRegistry.getJobInstance(jobName)).thenReturn(jobInstance);
        when(jobInstance.getIp()).thenReturn("127.0.0.1");
        when(serverService.hasAvailableServers()).thenReturn(false);
        when(jobRegistry.isShutdown(jobName)).thenReturn(false);
        boolean isLeader = leaderService.isLeaderUntilBlock();
        assertFalse(isLeader);
        verify(serverService, times(1)).hasAvailableServers();
        verify(leaderService, never()).electLeader();
    }
}
