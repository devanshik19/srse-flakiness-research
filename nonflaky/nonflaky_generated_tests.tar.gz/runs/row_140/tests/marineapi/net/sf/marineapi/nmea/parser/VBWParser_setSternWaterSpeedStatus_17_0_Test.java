package net.sf.marineapi.nmea.parser;

import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.List;
import org.junit.Before;
import org.junit.Test;
import net.sf.marineapi.nmea.parser.VBWParser;
import net.sf.marineapi.nmea.sentence.TalkerId;
import net.sf.marineapi.nmea.util.DataStatus;
import org.junit.After;
import org.junit.Assert;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import net.sf.marineapi.nmea.sentence.SentenceId;
import net.sf.marineapi.nmea.sentence.VBWSentence;
import org.mockito.*;
import static org.mockito.Mockito.*;
import static org.junit.Assert.*;

@RunWith(MockitoJUnitRunner.class)
public class VBWParser_setSternWaterSpeedStatus_17_0_Test {

    private VBWParser vbwParser;

    @Before
    public void setUp() {
        // Assuming TalkerId.GP is a valid enum value
        vbwParser = new VBWParser(TalkerId.GP);
    }

    @Test
    public void testSetSternWaterSpeedStatus() {
        try {
            // Assuming DataStatus has a VALID enum constant
            // Corrected to a valid constant
            DataStatus mockStatus = DataStatus.ACTIVE;
            // Invoke the private method setCharValue using reflection
            Method setCharValueMethod = VBWParser.class.getDeclaredMethod("setCharValue", int.class, char.class);
            setCharValueMethod.setAccessible(true);
            // Call the setSternWaterSpeedStatus method
            vbwParser.setSternWaterSpeedStatus(mockStatus);
            // Retrieve the value set in the fields list
            Field fieldsField = VBWParser.class.getSuperclass().getDeclaredField("fields");
            fieldsField.setAccessible(true);
            @SuppressWarnings("unchecked")
            List<String> fields = (List<String>) fieldsField.get(vbwParser);
            // Validate the result
            assertEquals(String.valueOf(mockStatus.toChar()), fields.get(VBWParser.STERN_SPEED_STATUS));
        } catch (NoSuchMethodException | IllegalAccessException | NoSuchFieldException e) {
            fail("Reflection failed: " + e.getMessage());
        }
    }
}
