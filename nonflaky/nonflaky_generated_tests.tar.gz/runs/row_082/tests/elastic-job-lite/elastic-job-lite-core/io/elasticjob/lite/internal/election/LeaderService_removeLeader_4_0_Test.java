package io.elasticjob.lite.internal.election;

import io.elasticjob.lite.internal.election.LeaderService;
import io.elasticjob.lite.internal.storage.JobNodeStorage;
import io.elasticjob.lite.reg.base.CoordinatorRegistryCenter;
import org.junit.Before;
import org.junit.Test;
import java.lang.reflect.Field;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import org.mockito.*;
import org.junit.After;
import org.junit.Assert;
import static org.mockito.Mockito.*;
import static org.junit.Assert.*;
import io.elasticjob.lite.internal.schedule.JobRegistry;
import io.elasticjob.lite.internal.server.ServerService;
import io.elasticjob.lite.internal.storage.LeaderExecutionCallback;
import io.elasticjob.lite.util.concurrent.BlockUtils;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@RunWith(MockitoJUnitRunner.class)
public class LeaderService_removeLeader_4_0_Test {

    private LeaderService leaderService;

    @Mock
    private CoordinatorRegistryCenter regCenterMock;

    @Mock
    private JobNodeStorage jobNodeStorageMock;

    @Before
    public void setUp() throws Exception {
        String jobName = "testJob";
        leaderService = new LeaderService(regCenterMock, jobName);
        // Use reflection to set the private jobNodeStorage field
        Field jobNodeStorageField = LeaderService.class.getDeclaredField("jobNodeStorage");
        jobNodeStorageField.setAccessible(true);
        jobNodeStorageField.set(leaderService, jobNodeStorageMock);
    }

    @Test
    public void testRemoveLeader() throws Exception {
        leaderService.removeLeader();
        verify(jobNodeStorageMock).removeJobNodeIfExisted(any());
    }
}
